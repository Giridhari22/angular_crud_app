import { Injectable } from '@angular/core';
import { Observable , BehaviorSubject } from 'rxjs';
import { Note } from '../interfaces/note';
// BehaviorSubject is used to sync the data between two or more components

@Injectable({
  providedIn: 'root'
})
export class NoteService {
  // this below is the variable
  private notes: Note[] = [];
  private noteSubject= new BehaviorSubject<Note[]>([]);
  constructor() { }

  getNotesObservable(): Observable<Note[]> {
    return this.noteSubject.asObservable();
  }

  createNote(note: Note): void{
    note.id = this.notes.length;
    this.notes.push(note);
    this.noteSubject.next(this.notes);
  }
}
